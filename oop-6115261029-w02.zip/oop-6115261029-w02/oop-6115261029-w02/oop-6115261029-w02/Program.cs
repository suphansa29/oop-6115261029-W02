﻿using System;

namespace oop_6115261029_w02
{
    class Program
    {
        static void Main(string[] args)
        {
            Room r434 = new Room("434", "434", 4, 4, "Computer");
            Console.WriteLine(r434);
            Building b4 = new Building("4 ", " Computer ", " 5.265 ", " 562.545 ");
            Console.WriteLine(b4);
            Subject th = new Subject("33521 " , " thai " , " 3 " ,  " 4 ", " 2 ");
            Console.WriteLine(th);
            Lecturer tc = new Lecturer("suphansa ", " janthangam ", " Teacher ");
            Console.WriteLine(tc);
            Section kk = new Section("343 ", " 01 ", " Computer ", " T.kwang ", " 25 Oct ", " 08.30 ", " 12.00 ");
            Console.WriteLine(kk);
            Programm oo = new Programm("Com ", " Bachelor degree ");
            Console.WriteLine(oo);
        }

    }
}
